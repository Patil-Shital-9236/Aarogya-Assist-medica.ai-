from setuptools import find_packages, setup

setup(
    name='Medical Chatbot',
    version='0.0.0',
    author='Samir Mulla',
    author_email='mullasamir799@gmail.com',
    packages=find_packages(),
    install_requires = []
)